<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\widgets\LinkPager;

$this->title = 'My Yii Application';
?>

<style>
    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }
    .verified{
        color:green;
    }
    .unverified{
        color:red;
    }
</style>
<div class="site-index">
    <center>
        <h1>Welcome to data Manager!</h1>
        <p class="lead" style="color: green">
            <?php if (Yii::$app->session->hasFlash('message')) { ?>
            <div class="alert alert-dismissable alert-success">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo Yii::$app->session->getFlash('message'); ?>
            </div>
        <?php }; ?>
        </p>
        <span style="float: left;">
            <?= Html::a('Create User', ['/site/create'], ['class' => 'btn btn-primary']) ?>
        </span>
    </center>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <div class="body-content">
        <table>
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Profile Pic</th>
                    <th>Marks</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (count($details) > 0) {
                    foreach ($details as $detail) {
                        ?>
                        <tr>
                            <td><?php echo $detail->first_name; ?></td>
                            <td><?php echo $detail->last_name; ?></td>
                            <td><?php echo $detail->email; ?></td>
                            <td><img style="max-height: 60px;" src="<?php echo \Yii::getAlias("@studentImgUrl") . '/' . $detail->profile_picture; ?>"></td>
                            <td><?php echo $detail->marks; ?></td>
                            <td><?php echo ($detail->status === 1 ? '<span class="verified">Vefiried</span>' : '<span class="unverified">Not Vefiried</span>'); ?></td>
                           
                        <?php
                    }
                }
                ?>
            </tbody>
        </table>


    </div>
</div>
