<?php
/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\widgets\LinkPager;

$this->title = 'Create Details';
?>

<style>
    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }
</style>
<div class="site-index">

    <div class="body-content">
        <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>
        <p class="lead">Create New Record here</p>
        <div class="row">

            <div class="form-group">
                <div class="col-lg-8">
                    <?= $form->field($detail, 'first_name'); ?>
                </div>
                <div class="col-lg-8">
                    <?= $form->field($detail, 'last_name'); ?>
                </div>
                <div class="col-lg-8">
                    <?= $form->field($detail, 'email'); ?>
                </div>
                <div class="col-lg-8">
                    <?= $form->field($detail, 'marks'); ?>
                </div>
                <div class="col-lg-8">
                    <?php $statusArr = ['1' => "Verified", '0' => 'Unverified']; ?>
                    <?= $form->field($detail, 'status')->dropDownList($statusArr, ['prompt' => 'Select Status']) ?>
                </div>
                <div class="col-lg-8">
                    <?= $form->field($detail, 'profile_picture')->fileInput() ?>
                </div>
                
                <div class="col-lg-8">
                    <center> 
                            <?= Html::submitButton('Create Post', ['class' => 'btn btn-primary']); ?>
                        <a href="<?php echo yii::$app->homeUrl; ?>" class="btn btn-primary">Go Back to Home</a>
                    </center>
                </div>
            </div>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>
