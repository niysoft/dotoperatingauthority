<?php
Yii::setAlias('@studentImgPath', 'C:\wamp64\www\todo\uploads\\');
Yii::setAlias('@studentImgUrl', 'http://localhost/todo/uploads/');
return [
    'adminEmail' => 'admin@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',
];
