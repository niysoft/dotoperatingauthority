<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use yii\web\UploadedFile;

class SiteController extends Controller {

    /**
     * {@inheritdoc}
     */
    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex() {
        $details = \app\models\Details::find()
                ->where("status = 1")
                ->orderBy('id DESC')->all();
        return $this->render('home', ['details' => $details]);
    }
    
      public function actionManage() {
        $details = \app\models\Details::find()->orderBy('id DESC')->all();
        return $this->render('manage', ['details' => $details]);
    }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin() {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }

        $model->password = '';
        return $this->render('login', [
                    'model' => $model,
        ]);
    }

    public function actionCreate() {
        $details = new \app\models\Details();
        if (Yii::$app->request->isPost) {
            $formData = \Yii::$app->request->post();
//            die(print_r($formData));
            if ($details->load($formData)) {  //die(print_r($_FILES));
                $image = UploadedFile::getInstance($details, 'profile_picture');
                if ($details->save() && $image != null) {

                    $insertId = $details->id;
                    $new_img_name = time() . '_' . $insertId . '.' . @$image->getExtension();
                    $image->saveAs(\Yii::getAlias("@studentImgPath") . '/' . $new_img_name);
                    $details->profile_picture = $new_img_name;
                    //$details->status = 1;
                    $details->save();
                    //}
                    \Yii::$app->getSession()->setFlash('message', 'Record created successfully!');
                    return $this->redirect(['index']);
                } else {
                    die(print_r($details->getErrors()));
                    \Yii::$app->getSession()->setFlash('message', 'Record could not be created!');
                }
            }
        }
        return $this->render('create', ['detail' => $details]);
    }

    public function actionUpdate($id) {
        $detail = \app\models\Details::findOne($id);
        if ($detail->load(\Yii::$app->request->post()) && $detail->save()) {
            Yii::$app->getSession()->setFlash('message', 'Record updated successfully');
            return $this->redirect(['index', 'id' => $detail->id]);
        } else {
            return $this->render('update', ['detail' => $detail]);
        }
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout() {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionContact() {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');
            return $this->refresh();
        }
        return $this->render('contact', [
                    'model' => $model,
        ]);
    }

    public function actionDelete($id) {
        $detail = \app\models\Details::findOne($id)->delete();
        if ($detail) {
            \Yii::$app->getSession()->setFlash('message', 'Record deleted successfully');
            return $this->redirect(['index']);
        }
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout() {
        return $this->render('about');
    }

}
