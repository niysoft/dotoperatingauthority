/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50724
Source Host           : localhost:3306
Source Database       : students

Target Server Type    : MYSQL
Target Server Version : 50724
File Encoding         : 65001

Date: 2019-07-14 18:36:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for details
-- ----------------------------
DROP TABLE IF EXISTS `details`;
CREATE TABLE `details` (
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `marks` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of details
-- ----------------------------
INSERT INTO `details` VALUES ('Badmus', 'Jigawa', 'jigawa@hotmail.com', '1563114035_20.png', '38', '0', '20');
INSERT INTO `details` VALUES ('Fatai', 'Akinlabi', 'akin@hotmail.com', '1563122810_25.png', '77', '0', '25');
INSERT INTO `details` VALUES ('Salaudeen', 'Niyi', 'niyi@synnods.com', '1563122269_24.png', '11', '1', '24');
INSERT INTO `details` VALUES ('Ajiki Olamide', 'Niyi', 'niyi@synnods.com', '1563123564_26.jpg', '32', '1', '26');
INSERT INTO `details` VALUES ('Salaudeen', 'Niyi', 'niyi@synnods.com', '1563106770_18.jpg', '32', '1', '18');
INSERT INTO `details` VALUES ('Olawale', 'fatai', 'fatai@hotmail.com', '1563125716_28.png', '37', '1', '28');
