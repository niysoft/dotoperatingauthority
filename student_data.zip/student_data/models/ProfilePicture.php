<?php
namespace app\models;

use yii\base\Model;
use yii\web\UploadedFile;

class UploadForm extends Model
{
    /**
     * @var UploadedFile
     */
    public $profile_picture;

    public function rules()
    {
        return [
            [['profile_picture'], 'file', 'skipOnEmpty' => false, 'extensions' => 'png, jpeg, jpg'],
        ];
    }
    
    public function upload()
    {
        if ($this->validate()) {
            $this->profile_picture->saveAs('uploads/' . $this->profile_picture->baseName . '.' . $this->profile_picture->extension);
            return true;
        } else {
            return false;
        }
    }
}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

