<?php
namespace app\models;

use yii\db\ActiveRecord;

class Details extends ActiveRecord{
    private $first_name;
    private $last_name;
    private $email;
    private $profile_picture;
    private $marks;
    private $status;
    private $id;
    
    public function rules(){
        return [
          [['first_name', 'last_name', 'email', 'marks', 'status'], 'required'],
            //[['profile_picture'], 'file', 'skipOnEmpty' => false, 'extensions' => 'png, jpg, jpeg']
        ];
    }
    
//    public function upload()
//    {
//        if ($this->validate()) {
//            $this->profile_picture->saveAs('uploads/' . $this->imageFile->baseName . '.' . $this->imageFile->extension);
//            return true;
//        } else {
//            return false;
//        }
//    }
   
}
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

